﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Repositories;
using Restaurant.Infrastructure.Persistance.Repository.CityRepository;
using System.Reflection;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CityController : Controller
    {       
            private readonly ICityService cityService;
            private readonly IMapper mapper;

            public CityController(ICityService cityService, IMapper mapper)
            {
                this.cityService = cityService;
                this.mapper = mapper;
            }
            [HttpGet]
            public async Task<IActionResult> GetAllCitiesAsync()
            {
                var cities = await cityService.GetAllAsync();

 
            //var citiesDTO = mapper.Map<List<Restaurant.Infrastructure.Persistance.DTO.RestaurantCity>>(cities);
                return Ok(cities);

            }

            [HttpGet]
            [Route("{id:guid}")]
            [ActionName("GetCitiesAsync")]
            public async Task<IActionResult> GetCitiesAsync(Guid id)
            {
                var city = await cityService.GetAsync(id);

                if (city == null)
                {
                    return NotFound();
                }


            //var cityDTO = mapper.Map<Restaurant.Infrastructure.Persistance.DTO.RestaurantCity>(city);
            return Ok(city);
        }

        [HttpPost]
            public async Task<IActionResult> AddCitiesAsync(Restaurant.Infrastructure.Persistance.DTO.AddCityRequest addCityRequest)
            {
                //Request to Domain Model
                var city = new Restaurant.Domain.Entities.RestaurantCity()
                {

                    CityName = addCityRequest.CityName,
                    UpdatedBy = addCityRequest.UpdatedBy,
                    UpdatedDate = addCityRequest.UpdatedDate

                };
                //pass details to Repository
                city = await cityService.AddAsync(city);
                //Convert back to DTO
                var cityDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantCity
                {
                    CityName = city.CityName,
                    UpdatedBy = city.UpdatedBy,
                    UpdatedDate = city.UpdatedDate

                };
                return CreatedAtAction(nameof(GetCitiesAsync), new { id = cityDTO.CityID }, cityDTO);

            }

            [HttpDelete]
            [Route("{id:guid}")]
            public async Task<IActionResult> DeleteCitiesAsync(Guid id)
            {
                //get restaurants from database
                var city = await cityService.DeleteAsync(id);

                //If null not found
                if (city == null)
                {
                    return NotFound();
                }

                //convert response back to DTO

                var cityDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantCity
                {
                    CityID = city.CityID,
                    CityName = city.CityName,
                    UpdatedBy = city.UpdatedBy,
                    UpdatedDate = city.UpdatedDate
                };
                //return ok response
                return Ok(cityDTO);
            }

            [HttpPut]
            [Route("{id:guid}")]
            public async Task<IActionResult> UpdatedCityAsync(Guid id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateCityRequest updateCityRequest)
            {
                var city = new Restaurant.Domain.Entities.RestaurantCity()
                {
                    CityName = updateCityRequest.CityName,
                    UpdatedBy = updateCityRequest.UpdatedBy,
                    UpdatedDate = updateCityRequest.UpdatedDate

                };


                // Update Region using repository
                city = await cityService.UpdateAsync(id, city);


                // If Null then NotFound
                if (city == null)
                {
                    return NotFound();
                }

                // Convert Domain back to DTO
                var cityDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantCity()
                {
                    CityID = city.CityID,
                    CityName = city.CityName,
                    UpdatedBy = city.UpdatedBy,
                    UpdatedDate = city.UpdatedDate
                };


                // Return Ok response
                return Ok(cityDTO);
            }
        }
    }
