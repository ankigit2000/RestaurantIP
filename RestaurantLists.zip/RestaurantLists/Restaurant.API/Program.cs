using Restaurant.Infrastructure.Persistance.Data;
using Restaurant.Infrastructure.Persistance.Repository;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using Restaurant.Domain.Repositories;
using System;
using Restaurant.Infrastructure.Persistance.Repository.CityRepository;
using Restaurant.Application.Common.Interfaces;
using Restaurant.Application.Common.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<RestaurantDetailsDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("RestaurantMasterDetails"));
});



/*builder.Services.RestaurantdetailsDbContext<RestaurantDetailsDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("RestaurantMasterList"));
});*/
builder.Services.AddScoped<ICityRepository, CityRepository>();
builder.Services.AddScoped<ICityService, CityService>();
builder.Services.AddAutoMapper(typeof(Program).Assembly);

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
