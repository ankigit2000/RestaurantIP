﻿using Microsoft.EntityFrameworkCore;
using Restaurant.Infrastructure.Persistance.DTO;
using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.Data
{
    /*internal class AppDBContext
    {
    }
    */
    public class RestaurantDetailsDbContext : DbContext
    {
        public RestaurantDetailsDbContext(DbContextOptions<RestaurantDetailsDbContext> options) : base(options)
        {

        }
        
        public DbSet<Domain.Entities.RestaurantCity> City { get; set; }
        

    }

}
