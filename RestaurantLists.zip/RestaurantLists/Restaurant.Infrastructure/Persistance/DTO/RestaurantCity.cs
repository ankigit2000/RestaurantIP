﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Infrastructure.Persistance.DTO
{
    /*internal class RestaurantCity
    {
    }*/
    public class RestaurantCity
    {
        [Key]
        public Guid CityID { get; set; }
        public string CityName { get; set; }
        public int UpdatedBy { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
