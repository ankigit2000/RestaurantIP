﻿using Restaurant.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Repositories
{
    /*internal interface ICityRepository
    {
    }*/
    public interface ICityRepository
        //<T> where T : BaseEntity
    {
        Task<IEnumerable<RestaurantCity>> GetAllAsync();
        Task<RestaurantCity> GetAsync(Guid id);

        Task<RestaurantCity> AddAsync(RestaurantCity city);

        Task<RestaurantCity> DeleteAsync(Guid id);

        Task<RestaurantCity> UpdateAsync(Guid id,RestaurantCity updated);
        
    }
}
