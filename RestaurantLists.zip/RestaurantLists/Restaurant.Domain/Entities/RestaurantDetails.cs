﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Entities
{
    public class RestaurantDetails:BaseEntity
    {
        //[Key]
        public Guid RestaurantID { get; set; }
        public string Restaurant { get; set; }
        public string Specialities { get; set; }
        public string AdditionalFeatures { get; set; }

        //[ForeignKey("Location")]
        public Guid LocationID { get; set; }
        //public virtual RestaurantLocation Location { get; set; }

        //[ForeignKey("Menu")]
        public Guid MenuID { get; set; }
        //public virtual RestaurantMenu Menu { get; set; }

        //[ForeignKey("Users")]
        public Guid UserID { get; set; }
        //public virtual Users Users { get; set; }
        
    }
}
