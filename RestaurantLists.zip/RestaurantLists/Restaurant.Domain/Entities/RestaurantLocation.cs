﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Domain.Entities
{
    public class RestaurantLocation:BaseEntity
    {
        [Key]
        public Guid LocationID { get; set; }
        public string Address { get; set; }
        public virtual RestaurantCity City { get; set; }

        //public Guid CityID { get; set; }
        //public RestaurantCity City { get; set; }
        //public Guid StateID { get; set; }
        //public RestaurantState State { get; set; }
        
    }
}
