﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using Restaurant.Infrastructure.Persistance.Repository.CityRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class CityService : ICityService
    {
        private readonly ICityRepository _cityRepository;

        public CityService(ICityRepository _cityRepository) 
        {
            this._cityRepository = _cityRepository;
        }

        public Task<RestaurantCity> AddAsync(RestaurantCity city)
        {
           return _cityRepository.AddAsync(city);
        }

        public Task<RestaurantCity> DeleteAsync(Guid id)
        {
            return _cityRepository.DeleteAsync(id);
        }

        public Task<IEnumerable<RestaurantCity>> GetAllAsync()
        {
           return _cityRepository.GetAllAsync();    
        }

        public Task<RestaurantCity> GetAsync(Guid id)
        {
            return _cityRepository.GetAsync(id);
        }

        public Task<RestaurantCity> UpdateAsync(Guid id, RestaurantCity updated)
        {
            return _cityRepository.UpdateAsync(id, updated);    
        }
    }
}
