﻿namespace Restaurant.Application
{
    public class Class1
    {

    }
}